import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
    public static void join_union_between_two_country(Country country_1 , Country country_2){
        if(country_1.is_union(country_2)){
            System.out.println("something went wrong!");
            return;
        }
        if(country_2.is_enemy(country_1)){
            System.out.println("something went wrong!");
            return;
        }
        for(Country i: country_1.union){
            if(i.is_enemy(country_2)==true){
                System.out.println("something went wrong!");
                return;
            }
        }
        for(Country i: country_1.enemy){
            if(i.is_union(country_2)==true){
                System.out.println("something went wrong!");
                return;
            }
        }
        for(Country i: country_2.union){
            if(i.is_enemy(country_1)==true){
                System.out.println("something went wrong!");
                return;
            }
        }
        for(Country i: country_2.enemy){
            if(i.is_union(country_1)==true){
                System.out.println("something went wrong!");
                return;
            }
        }
        country_1.add_union(country_2);
        country_2.add_union(country_1);
        System.out.println("unionized successfully!");
    }
    public static void join_enemy_between_two_country(Country country_1 , Country country_2){
        if(country_1.is_union(country_2)){
            System.out.println("something went wrong!");
            return;
        }
        if(country_2.is_enemy(country_1)){
            System.out.println("something went wrong!");
            return;
        }
        for(Country i: country_1.union){
            if(i.is_union(country_2)==true){
                System.out.println("something went wrong!");
                return;
            }
        }
        for(Country i: country_1.enemy){
            if(i.is_enemy(country_2)==true){
                System.out.println("something went wrong!");
                return;
            }
        }
        for(Country i: country_2.union){
            if(i.is_union(country_1)==true){
                System.out.println("something went wrong!");
                return;
            }
        }
        for(Country i: country_2.enemy){
            if(i.is_enemy(country_1)==true){
                System.out.println("something went wrong!");
                return;
            }
        }
        country_1.add_enemy(country_2);
        country_2.add_enemy(country_1);
        System.out.println("enemy made successfully!");
    }
    public static void join_union_between_number_of_countries(Country[] countries){
        for(int i = 0 ; i<countries.length ; i++){
            for(int j = i+1 ; j<countries.length ; j++){
                if(countries[i].is_union(countries[j]) || countries[i].is_enemy(countries[j])){
                    System.out.println("something went wrong!");
                    return;
                }
                for(Country k: countries[i].union){
                    if(k.is_enemy(countries[j])==true){
                        System.out.println("something went wrong!");
                        return;
                    }
                }
                for(Country k: countries[i].enemy){
                    if(k.is_union(countries[j])==true){
                        System.out.println("something went wrong!");
                        return;
                    }
                }
                for(Country k: countries[i].union){
                    if(k.is_enemy(countries[j])==true){
                        System.out.println("something went wrong!");
                        return;
                    }
                }
                for(Country k: countries[i].enemy){
                    if(k.is_union(countries[j])==true){
                        System.out.println("something went wrong!");
                        return;
                    }
                }
            }
        }
        for(int i = 0 ; i<countries.length ; i++){
            for(int j = 0 ; j<countries.length ; j++){
                if(i!=j){
                    countries[i].add_union(countries[j]);
                }
            }
        }
        System.out.println("unionized successfully! ");
    }
    public static void main(String [] args){
        Scanner scanner = new Scanner(System.in);
        String a="" ;
        ArrayList<Country>countries = new ArrayList<>();
        while(!(a.equals("end"))){
            a=scanner.nextLine();
            if(a.equals("end"))
                break;
            String c[]=a.split("\\s+");
            boolean result = false ;
            switch(c[0]){
                case "create":
                    switch (c[1]){
                        case "country":
                            boolean x = false;
                            for(int i = 0 ; i< countries.size() ; i++){
                                if(countries.get(i).getName().equalsIgnoreCase(c[2])){
                                    System.out.println("country was created");
                                    x = true ;
                                }
                            }
                            if(x==false){
                                Country country = new Country(c[2],c[3]);
                                countries.add(country);
                                System.out.println("country "+c[2]+" created");
                            }
                            result =true ;
                            break;
                        case "corps":
                            x = false ;
                            int infantry = Integer.parseInt(c[2])*1000;
                            int cavalry = Integer.parseInt(c[3])*400;
                            int artillery = Integer.parseInt(c[4])*10;
                            if((infantry+cavalry+artillery)>30000){
                                System.out.println("cannot have more than 30k in a corps!");
                                x=true ;
                            }
                            if(x==false) {
                                for (int i = 0; i < countries.size(); i++) {
                                    if(countries.get(i).getName().equalsIgnoreCase(c[7])){
                                        result =true ;
                                        break;
                                    }
                                    if(i==countries.size()-1){
                                        System.out.println("country was not found!");
                                        x=true ;
                                    }
                                }
                            }
                            if(x==false){
                                for(Country country : countries){
                                    if(country.getName().equalsIgnoreCase(c[7])){
                                        country.add_corp(infantry,cavalry,artillery,c[5],c[8]);
                                    }
                                }
                            }
                            result =true ;
                            break;
                        case "army":
                            x = false ;
                                for (int i = 0; i < countries.size(); i++) {
                                    if(countries.get(i).getName().equalsIgnoreCase(c[5])){
                                        result =true ;
                                        break;
                                    }
                                    if(i==countries.size()-1){
                                        System.out.println("country was not found!");
                                        x=true ;
                                    }
                                }
                            if(x==false){
                                for(Country country : countries){
                                    if(country.getName().equalsIgnoreCase(c[5])){
                                        if(c.length==8){
                                            country.add_army(c[2],c[3],c[7]);
                                        }
                                        if(c.length==6){
                                            country.add_army(c[2],c[3],"");
                                        }
                                    }
                                }
                            }
                            result =true ;
                            break;
                    }
                    result =true ;
                    break;
                case "set":
                    switch (c[1]){
                        case "place":
                            boolean x = false ;
                            for (int i = 0; i < countries.size(); i++) {
                                if(countries.get(i).getName().equalsIgnoreCase(c[3])){
                                    result =true ;
                                    break;
                                }
                                if(i==countries.size()-1){
                                    System.out.println("country was not found!");
                                    x=true ;
                                }
                            }
                            if(x==false){
                                for(Country country : countries){
                                    if(country.getName().equalsIgnoreCase(c[3])){
                                        country.set_place_for_army(c[4],c[6]);
                                    }
                                }
                            }

                            result =true ;
                            break;
                    }
                    result =true ;
                    break;
                case"add":
                    boolean x = false ;
                    for (int i = 0; i < countries.size(); i++) {
                        if(countries.get(i).getName().equalsIgnoreCase(c[7])){
                            result =true ;
                            break;
                        }
                        if(i==countries.size()-1){
                            System.out.println("country was not found!");
                            x=true ;
                        }
                    }
                    if(x==false){
                        for(Country country : countries){
                            if(country.getName().equalsIgnoreCase(c[7])){
                                Army army = country.find_army_in_country(c[5]);
                                if(army==null){
                                    System.out.println("army was not found!");
                                    x=true ;
                                }
                                if(x==false){
                                    Corp corp = country.find_corp_in_country(c[2]);
                                    if(corp==null){
                                        System.out.println("corps was not found!");
                                        x=true ;
                                    }
                                }
                                if(x==false){
                                    Corp corp = country.find_corp_in_country(c[2]);
                                    country.add_corp_to_army(corp,army);
                                }
                            }
                        }
                    }
                    result =true ;
                    break;
                case "print":
                    switch (c[1]){
                        case "army":
                            switch (c[2]){
                                case "with":
                                    x=false;
                                    for (int i = 0; i < countries.size(); i++) {
                                        if(countries.get(i).getName().equalsIgnoreCase(c[5])){
                                            result =true ;
                                            break;
                                        }
                                        if(i==countries.size()-1){
                                            System.out.println("country was not found!");
                                            x=true ;
                                        }
                                    }
                                    if(x==false){
                                        for(Country country : countries){
                                            if(country.getName().equalsIgnoreCase(c[5])){
                                                Army army = country.find_army_in_country(c[4]);
                                                if(army==null){
                                                    System.out.println("army was not found!");
                                                    x=true ;
                                                }
                                                if(x==false){
                                                    System.out.println(army.getLeader()+" "+army.number_of_corp());
                                                    army.sort_corp_and_print();
                                                }
                                            }
                                        }
                                    }
                                    result =true ;
                                    break;
                                default:
                                    x=false ;
                                    for (int i = 0; i < countries.size(); i++) {
                                        if(countries.get(i).getName().equalsIgnoreCase(c[3])){
                                            result =true ;
                                            break;
                                        }
                                        if(i==countries.size()-1){
                                            System.out.println("country was not found!");
                                            x=true ;
                                        }
                                    }
                                    if(x==false){
                                        for(Country country : countries){
                                            if(country.getName().equalsIgnoreCase(c[3])){
                                                Army army = country.find_army_in_country(c[2]);
                                                if(army==null){
                                                    System.out.println("army was not found!");
                                                    x=true ;
                                                }
                                                if(x==false){
                                                    System.out.println(army.getLeader()+" "+army.number_of_corp());
                                                }
                                            }
                                        }
                                    }
                                    result =true ;
                                    break;
                            }
                            result =true ;
                            break;
                        case "country":
                            switch (c[2]){
                                case "with":
                                    x=false;
                                    for (int i = 0; i < countries.size(); i++) {
                                        if(countries.get(i).getName().equalsIgnoreCase(c[4])){
                                            result =true ;
                                            break;
                                        }
                                        if(i==countries.size()-1){
                                            System.out.println("country was not found!");
                                            x=true ;
                                        }
                                    }
                                    if(x==false){
                                        for(Country country : countries){
                                            if(country.getName().equalsIgnoreCase(c[4])){
                                                country.print_country_with_detail();
                                            }
                                        }
                                    }
                                    result =true ;
                                    break;
                                default:
                                    x=false;
                                    for (int i = 0; i < countries.size(); i++) {
                                        if(countries.get(i).getName().equalsIgnoreCase(c[2])){
                                            result =true ;
                                            break;
                                        }
                                        if(i==countries.size()-1){
                                            System.out.println("country was not found!");
                                            x=true ;
                                        }
                                    }
                                    if(x==false){
                                        for(Country country : countries){
                                            if(country.getName().equalsIgnoreCase(c[2])){
                                                country.print_country();
                                            }
                                        }
                                    }
                                    result =true ;
                                    break;
                            }
                            result =true ;
                            break;
                        case "score":
                            if(c.length==6){
                                x=false;
                                for (int i = 0; i < countries.size(); i++) {
                                    if(countries.get(i).getName().equalsIgnoreCase(c[3])){
                                        result =true ;
                                        break;
                                    }
                                    if(i==countries.size()-1){
                                        System.out.println("country was not found!");
                                        x=true ;
                                    }
                                }
                                if(x==false){
                                    for(Country country : countries){
                                        if(country.getName().equalsIgnoreCase(c[3])){
                                            Army army = country.find_army_in_country(c[4]);
                                            if(army==null){
                                                System.out.println("army was not found!");
                                                x=true ;
                                            }
                                            if(x==false){
                                                Corp corp = country.find_corp_in_country(c[5]);
                                                if(corp==null){
                                                    System.out.println("corps was not found!");
                                                    x=true ;
                                                }
                                            }
                                            if(x==false){
                                                Corp corp = country.find_army_in_country(c[4]).find_corp_in_army(c[5]);
                                                if(corp==null){
                                                    System.out.println("this corps is not in this army!");
                                                }
                                            }
                                            if(x==false){
                                                System.out.println(country.find_army_in_country(c[4]).find_corp_in_army(c[5]).get_score_in_corp(country.find_army_in_country(c[4]).getPlace()));
                                            }
                                        }
                                    }
                                }

                            }
                            else if(c.length==5){
                                x=false;
                                for (int i = 0; i < countries.size(); i++) {
                                    if(countries.get(i).getName().equalsIgnoreCase(c[3])){
                                        result =true ;
                                        break;
                                    }
                                    if(i==countries.size()-1){
                                        System.out.println("country was not found!");
                                        x=true ;
                                    }
                                }
                                if(x==false){
                                    for(Country country : countries){
                                        if(country.getName().equalsIgnoreCase(c[3])){
                                            Army army = country.find_army_in_country(c[4]);
                                            if(army==null){
                                                System.out.println("army was not found!");
                                                x=true ;
                                            }
                                            if(x==false){
                                                System.out.println(country.find_army_in_country(c[4]).sum_score_army());
                                            }
                                        }
                                    }
                                }

                            }
                            else if(c.length==4){
                                x=false;
                                for (int i = 0; i < countries.size(); i++) {
                                    if(countries.get(i).getName().equalsIgnoreCase(c[3])){
                                        result =true ;
                                        break;
                                    }
                                    if(i==countries.size()-1){
                                        System.out.println("country was not found!");
                                        x=true ;
                                    }
                                }
                                if(x==false){
                                    for(Country country : countries){
                                        if(country.getName().equalsIgnoreCase(c[3])){
                                            if(x==false){
                                                System.out.println(country.sum_score());
                                            }
                                        }
                                    }
                                }


                            }
                            result =true ;
                            break;

                    }
                    result =true ;
                    break;
                case"show":
                    switch (c[1]){
                        case"friends":
                            x=false;
                            for (int i = 0; i < countries.size(); i++) {
                                if(countries.get(i).getName().equalsIgnoreCase(c[3])){
                                    result =true ;
                                    break;
                                }
                                if(i==countries.size()-1){
                                    System.out.println("country was not found!");
                                    x=true ;
                                }
                            }
                            if(x==false) {
                                for (Country country : countries) {
                                    if (country.getName().equalsIgnoreCase(c[3])) {
                                        country.print_friends();
                                    }
                                }
                            }

                            result =true ;
                            break;
                        case "enemies":
                            x=false;
                            for (int i = 0; i < countries.size(); i++) {
                                if(countries.get(i).getName().equalsIgnoreCase(c[3])){
                                    result =true ;
                                    break;
                                }
                                if(i==countries.size()-1){
                                    System.out.println("country was not found!");
                                    x=true ;
                                }
                            }
                            if(x==false) {
                                for (Country country : countries) {
                                    if (country.getName().equalsIgnoreCase(c[3])) {
                                        country.print_enemies();
                                    }
                                }
                            }
                            result =true ;
                            break;
                    }
                    result =true ;
                    break;
                case "war":
                    if(c.length==5){
                        x=false;
                        for (int i = 0; i < countries.size(); i++) {
                            if(countries.get(i).getName().equalsIgnoreCase(c[2])){
                                result =true ;
                                break;
                            }
                            if(i==countries.size()-1){
                                System.out.println("country was not found!");
                                x=true ;
                            }
                        }
                        if(x==false){
                            for (int i = 0; i < countries.size(); i++) {
                                if(countries.get(i).getName().equalsIgnoreCase(c[4])){
                                    result =true ;
                                    break;
                                }
                                if(i==countries.size()-1){
                                    System.out.println("country was not found!");
                                    x=true ;
                                }
                            }
                        }
                        if(x==false){
                            Country country_1=null,country_2=null ;
                            for (int i = 0; i < countries.size(); i++) {
                                if(countries.get(i).getName().equalsIgnoreCase(c[2])){
                                    country_1=countries.get(i);
                                    result =true ;
                                }
                                if(countries.get(i).getName().equalsIgnoreCase(c[4])){
                                    country_2=countries.get(i);
                                    result =true ;
                                }

                            }
                            if(country_1.sum_score()>country_2.sum_score()){
                                System.out.println(country_1.getName());
                                country_2.lose_in_war();
                            }
                            else {
                                System.out.println(country_2.getName());
                                country_1.lose_in_war();
                            }
                        }

                    }
                    if(c.length==7){
                        x=false;
                        for (int i = 0; i < countries.size(); i++) {
                            if(countries.get(i).getName().equalsIgnoreCase(c[2])){
                                result =true ;
                                break;
                            }
                            if(i==countries.size()-1){
                                System.out.println("country was not found!");
                                x=true ;
                            }
                        }
                        if(x==false){
                            for (int i = 0; i < countries.size(); i++) {
                                if(countries.get(i).getName().equalsIgnoreCase(c[4])){
                                    result =true ;
                                    break;
                                }
                                if(i==countries.size()-1){
                                    System.out.println("country was not found!");
                                    x=true ;
                                }
                            }
                        }
                        if(x==false){
                            Country country_1=null,country_2=null ;
                            for (int i = 0; i < countries.size(); i++) {
                                if(countries.get(i).getName().equalsIgnoreCase(c[2])){
                                    country_1=countries.get(i);
                                    result =true ;
                                }
                                if(countries.get(i).getName().equalsIgnoreCase(c[4])){
                                    country_2=countries.get(i);
                                    result =true ;
                                }

                            }
                            if(country_1.sum_score_in_place(c[6])>country_2.sum_score_in_place(c[6])){
                                System.out.println(country_1.getName());
                                country_2.lose_in_war();
                            }
                            else {
                                System.out.println(country_2.getName());
                                country_1.lose_in_war();
                            }
                        }

                    }
                    result =true ;
                    break;
                default:
                    switch (c[1]){
                        case "join":
                            x=false;
                            Pattern pattern = Pattern.compile("\\[");
                            Matcher matcher = pattern.matcher(c[4]);
                            if(matcher.find()){
                                Pattern pattern_1 = Pattern.compile("'([^']*)'");
                                Matcher matcher1 = pattern_1.matcher(c[4]);
                                ArrayList<String> asami = new ArrayList<>();
                                while (matcher1.find()) {
                                    asami.add(matcher1.group(1));
                                }
                                String[] final_countries =  asami.toArray(new String[0]);
                                for(int j = 0 ; j<final_countries.length && x==false ; j++){
                                    for (int i = 0; i < countries.size(); i++) {
                                        if(countries.get(i).getName().equalsIgnoreCase(final_countries[j])){
                                            result =true ;
                                            break;
                                        }
                                        if(i==countries.size()-1){
                                            System.out.println("country was not found!");
                                            x=true ;
                                        }
                                    }
                                }
                                if(x==false){
                                    Country[] country=new Country[final_countries.length+1];
                                    for(int j =0 ; j<final_countries.length ; j++){
                                        for (int i = 0; i < countries.size(); i++) {
                                            if (countries.get(i).getName().equalsIgnoreCase(final_countries[j])) {
                                                country[j]=countries.get(i);
                                                result = true;
                                                break;
                                            }
                                        }
                                    }
                                    for (int i = 0; i < countries.size(); i++) {
                                        if (countries.get(i).getName().equalsIgnoreCase(c[0])) {
                                            country[final_countries.length]=countries.get(i);
                                            result = true;
                                            break;
                                        }
                                    }
                                    join_union_between_number_of_countries(country);
                                }
                            }
                            else {
                                for (int i = 0; i < countries.size(); i++) {
                                    if(countries.get(i).getName().equalsIgnoreCase(c[0])){
                                        result =true ;
                                        break;
                                    }
                                    if(i==countries.size()-1){
                                        System.out.println("country was not found!");
                                        x=true ;
                                    }
                                }
                                if(x==false){
                                    for (int i = 0; i < countries.size(); i++) {
                                        if(countries.get(i).getName().equalsIgnoreCase(c[4])){
                                            result =true ;
                                            break;
                                        }
                                        if(i==countries.size()-1){
                                            System.out.println("country was not found!");
                                            x=true ;
                                        }
                                    }
                                }
                                if(x==false){
                                    Country country_1 = null,country_2=null ;
                                    for (int i = 0; i < countries.size(); i++) {
                                        if(countries.get(i).getName().equalsIgnoreCase(c[4])){
                                            country_1=countries.get(i);
                                            result =true ;
                                        }
                                        if(countries.get(i).getName().equalsIgnoreCase(c[0])){
                                            country_2=countries.get(i);
                                            result =true ;
                                        }
                                    }
                                    join_union_between_two_country(country_1,country_2);
                                }
                            }
                            result =true ;
                            break;
                        case "made":
                            x=false ;
                            for (int i = 0; i < countries.size(); i++) {
                                if(countries.get(i).getName().equalsIgnoreCase(c[0])){
                                    result =true ;
                                    break;
                                }
                                if(i==countries.size()-1){
                                    System.out.println("country was not found!");
                                    x=true ;
                                }
                            }
                            if(x==false){
                                for (int i = 0; i < countries.size(); i++) {
                                    if(countries.get(i).getName().equalsIgnoreCase(c[4])){
                                        result =true ;
                                        break;
                                    }
                                    if(i==countries.size()-1){
                                        System.out.println("country was not found!");
                                        x=true ;
                                    }
                                }
                            }
                            if(x==false){
                                Country country_1 = null,country_2=null ;
                                for (int i = 0; i < countries.size(); i++) {
                                    if(countries.get(i).getName().equalsIgnoreCase(c[4])){
                                        country_1=countries.get(i);
                                        result =true ;
                                    }
                                    if(countries.get(i).getName().equalsIgnoreCase(c[0])){
                                        country_2=countries.get(i);
                                        result =true ;
                                    }
                                }
                                join_enemy_between_two_country(country_1,country_2);
                            }

                            result =true ;
                            break;
                    }
                    break;
            }
            if(result==false){
                System.out.println("invalid input!");
            }
        }
    }
}