public abstract class Regiment {
    private int number ;

    public int getNumber() {
        return number;
    }
    public abstract void setNumber(int number);
}
